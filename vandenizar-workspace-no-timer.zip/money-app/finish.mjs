// Put <title> and the viewport-fit meta at the very top so the artifact host finds them.
import { readFileSync, writeFileSync } from 'fs';
const f = new URL('./dist/index.html', import.meta.url);
let s = readFileSync(f, 'utf8');
const head = [];
s = s.replace(/<title>[^<]*<\/title>\s*/, (m) => { head.push(m.trim()); return ''; });
s = s.replace(/<meta name="claude:viewport-fit-sides"[^>]*>\s*/, (m) => { head.push(m.trim()); return ''; });
writeFileSync(f, head.join('\n') + '\n<meta charset="utf-8" />\n' + s);
